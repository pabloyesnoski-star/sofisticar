export function Button({ children, className }) {
  return (
    <button className={`transition-all font-semibold ${className}`}>
      {children}
    </button>
  );
}